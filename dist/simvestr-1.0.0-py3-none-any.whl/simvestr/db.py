from pathlib import Path

import heapq

import pandas as pd
import numpy as np
from flask import current_app, g
import click
from flask.cli import with_appcontext
from simvestr.models import db


# Defines setup and tear down the database

def get_db():
    if "db" not in g:
        db.init_app(current_app)
        g.db = db

    return g.db


def close_db(e=None):
    db = g.pop("db", None)

    if db is not None:
        db.close()


def init_db():
    db = get_db()
    db.create_all()


def delete_db():
    curr_dir = Path.cwd()
    db_path = curr_dir / "instance" / "simvestr.db"
    db_path.unlink()


def bulk_add_from_df(df, db, model):
    df = df.replace({np.nan: None})
    df.columns = df.columns.str.lower()
    db.session.bulk_insert_mappings(
        model,
        df.to_dict(orient="records")
    )
    db.session.commit()


def populate_stocks():
    from .models import Exchanges, Stock
    import requests

    db = get_db()

    non_crypto_exchanges = Exchanges.query.with_entities(Exchanges.code).filter_by(is_crypto=False).all()
    crypto_exchanges = Exchanges.query.with_entities(Exchanges.code).filter_by(is_crypto=True).all()
    SYMBOL_ALL_API = lambda \
            ex: f"https://finnhub.io/api/v1/stock/symbol?exchange={ex}&" \
                f"token={current_app.config['FINNHUB_API_KEY']}"
    CRYPTO_SYMBOL_ALL_API = lambda \
            ex: f"https://finnhub.io/api/v1/crypto/symbol?exchange={ex}&" \
                f"token={current_app.config['FINNHUB_API_KEY']}"
    exchanges = {
        "stock": {
            "exchange":[x[0] for x in non_crypto_exchanges],
            "name": {
                "displaySymbol": "display_symbol",
                "description": "name"
            },
            "search": SYMBOL_ALL_API

        },
        "crypto": {
            "exchange":[x[0] for x in crypto_exchanges],
            "name": {
                "description": "name",
                "displaySymbol": "currency",  # please review, unsure if this is a good idea
            },
            "search": CRYPTO_SYMBOL_ALL_API
        },
    }


    exchange_stocks = []
    heapq.heapify(exchange_stocks)
    for ex_type, exchange_dict in exchanges.items():
        for exchange in exchange_dict["exchange"]:
            r = requests.get(exchange_dict["search"](exchange))
            df = pd.DataFrame.from_records(r.json())
            df["exchange"] = exchange
            df["type"] = ex_type
            df.rename(columns=exchange_dict["name"], inplace=True)
            heapq.heappush(
                exchange_stocks,
                (-len(df), {exchange: df})
            )

    while exchange_stocks:
        num_stocks, stock_dict = heapq.heappop(exchange_stocks)
        ex, df = stock_dict.popitem()
        unique_stocks = df.name.unique()
        sq = Stock.query.filter(Stock.name.in_(list(unique_stocks)))

        if sq:
            df = df[df.name.notin(unique_stocks)]

        if df:
            bulk_add_from_df(df, db, Stock)


def load_dummy():
    from .models import User, Watchlist, Stock, Portfolio, PortfolioPrice, Transaction, Exchanges
    db = get_db()
    data_path = Path.cwd() / "resources" / "test_data_user.xlsx"

    # Order of models matterss
    load_mapping = dict(
        users=User,
        # stock=Stock,
        watchlist=Watchlist,
        portfolio=Portfolio,
        portfolioprice=PortfolioPrice,
        transaction=Transaction,
        exchanges=Exchanges
    )

    for sheet, model in load_mapping.items():
        df = pd.read_excel(data_path, sheet_name=sheet)
        bulk_add_from_df(df, db, model)
    db.session.close()

    populate_stocks()


@click.command("init-db")
@with_appcontext
def init_db_command():
    """Clear the existing data and create new tables."""
    init_db()
    click.echo("Initialized the database.")


def init_app(app):
    app.teardown_appcontext(close_db)
    app.cli.add_command(init_db_command)
